# 🎮 NexaTopUp — Website Top Up Game

Website top up game lengkap dengan backend Node.js + Express dan integrasi payment gateway Midtrans.

---

## 📁 Struktur Folder

```
topup-game/
├── backend/
│   ├── server.js        ← Backend utama (API + server)
│   └── package.json
└── frontend/
    └── public/
        └── index.html   ← Frontend (HTML/CSS/JS)
```

---

## 🚀 Cara Menjalankan

### 1. Install Node.js
Download dari https://nodejs.org (versi 18 ke atas)

### 2. Install dependensi
```bash
cd topup-game/backend
npm install
```

### 3. Jalankan server
```bash
# Mode normal
npm start

# Mode development (auto-restart saat ada perubahan)
npm run dev
```

### 4. Buka browser
```
http://localhost:3000
```

---

## 💳 Setup Payment Gateway (Midtrans)

### Langkah A — Daftar akun Midtrans
1. Buka https://dashboard.midtrans.com
2. Daftar akun gratis
3. Masuk ke **Settings → Access Keys**
4. Salin **Server Key** dan **Client Key** (gunakan Sandbox untuk testing)

### Langkah B — Isi config di server.js
Buka file `backend/server.js`, cari bagian CONFIG dan ganti:

```javascript
const CONFIG = {
  MIDTRANS_SERVER_KEY: 'SB-Mid-server-xxxx',  // ← ganti dengan Server Key Anda
  MIDTRANS_CLIENT_KEY: 'SB-Mid-client-xxxx',  // ← ganti dengan Client Key Anda
  MIDTRANS_IS_PRODUCTION: false,               // ubah ke true jika sudah live
  APP_URL: 'http://localhost:3000',            // ganti dengan URL domain Anda
};
```

### Langkah C — Aktifkan Snap.js di frontend
Buka file `frontend/public/index.html`, cari baris paling bawah:

```html
<!-- <script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="YOUR_CLIENT_KEY"></script> -->
```

Hapus komentar (`<!--` dan `-->`) dan ganti `YOUR_CLIENT_KEY`:

```html
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-xxxx"></script>
```

### Langkah D — Setup Webhook (Notifikasi Pembayaran)
Di dashboard Midtrans:
1. Masuk ke **Settings → Configuration**
2. Isi **Payment Notification URL**: `https://domain-anda.com/api/payment/notify`
3. Simpan

---

## 🌐 Deploy ke Internet (VPS/Hosting)

### Opsi 1: Railway (Gratis, Mudah)
1. Buka https://railway.app, daftar dengan GitHub
2. New Project → Deploy from GitHub repo
3. Set environment variables (SERVER_KEY, CLIENT_KEY, dll.)
4. Domain otomatis diberikan

### Opsi 2: VPS (Ubuntu)
```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 (agar server jalan terus)
sudo npm install -g pm2

# Upload project ke server, lalu:
cd topup-game/backend
npm install
pm2 start server.js --name topup-game
pm2 startup  # agar otomatis jalan saat server restart
pm2 save
```

### Opsi 3: Vercel / Render
Kedua platform mendukung Node.js backend gratis.

---

## 🗄️ Ganti Database (Opsional)

Saat ini order disimpan di memory (hilang saat restart).
Untuk database permanen, ganti `const orders = new Map()` dengan:

### MySQL (via mysql2)
```bash
npm install mysql2
```
```javascript
const mysql = require('mysql2/promise');
const db = await mysql.createConnection({ host:'localhost', user:'root', password:'', database:'topup' });
await db.execute('CREATE TABLE IF NOT EXISTS orders (...)');
```

### MongoDB (via mongoose)
```bash
npm install mongoose
```

---

## 🎮 Tambah Game Baru

Di `backend/server.js`, tambahkan objek ke array `GAMES`:

```javascript
{
  id: 'honkai',
  name: 'Honkai: Star Rail',
  image: 'URL_GAMBAR',
  category: 'RPG',
  currency: 'Oneiric Shard',
  packages: [
    { id: 'honkai-1', amount: 60,  bonus: 0,  price: 15000 },
    { id: 'honkai-2', amount: 300, bonus: 30, price: 75000 },
    // ...
  ],
},
```

---

## 📡 Daftar API Endpoint

| Method | URL | Keterangan |
|--------|-----|------------|
| GET | /api/games | Daftar semua game |
| GET | /api/games/:id | Detail game |
| POST | /api/orders | Buat order baru |
| GET | /api/orders/:orderId | Cek status order |
| POST | /api/payment/notify | Webhook Midtrans |
| POST | /api/demo/pay/:orderId | Simulasi bayar (demo only) |

---

## ⚠️ Mode Demo (Tanpa Midtrans)

Jika Server Key belum diisi, website berjalan dalam **mode demo**:
- Transaksi tetap bisa dibuat
- Modal pembayaran simulasi akan muncul
- Klik salah satu metode bayar → status langsung SUCCESS
- Berguna untuk testing tampilan dan alur

---

## 📞 Kontak & Dukungan

Jika ada pertanyaan, silakan buka issue di GitHub atau hubungi via email.
