const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend/public')));

// ─────────────────────────────────────────────
//  CONFIG  (ganti dengan data asli Anda)
// ─────────────────────────────────────────────
const CONFIG = {
  MIDTRANS_SERVER_KEY: 'YOUR_MIDTRANS_SERVER_KEY',   // ← ganti
  MIDTRANS_CLIENT_KEY: 'YOUR_MIDTRANS_CLIENT_KEY',   // ← ganti
  MIDTRANS_IS_PRODUCTION: false,                      // true jika sudah live
  APP_URL: 'http://localhost:3000',
};

// ─────────────────────────────────────────────
//  PRODUK GAME  (bisa dipindah ke database)
// ─────────────────────────────────────────────
const GAMES = [
  {
    id: 'mlbb',
    name: 'Mobile Legends',
    image: 'https://i.imgur.com/8Km9tLL.png',
    category: 'MOBA',
    currency: 'Diamond',
    packages: [
      { id: 'mlbb-1',  amount: 11,    bonus: 0,   price: 3000  },
      { id: 'mlbb-2',  amount: 22,    bonus: 0,   price: 6000  },
      { id: 'mlbb-3',  amount: 56,    bonus: 0,   price: 14000 },
      { id: 'mlbb-4',  amount: 112,   bonus: 0,   price: 28000 },
      { id: 'mlbb-5',  amount: 275,   bonus: 14,  price: 69000 },
      { id: 'mlbb-6',  amount: 565,   bonus: 28,  price: 139000 },
      { id: 'mlbb-7',  amount: 1150,  bonus: 57,  price: 279000 },
      { id: 'mlbb-8',  amount: 2398,  bonus: 114, price: 559000 },
    ],
  },
  {
    id: 'ff',
    name: 'Free Fire',
    image: 'https://i.imgur.com/XmGBBmf.png',
    category: 'Battle Royale',
    currency: 'Diamond',
    packages: [
      { id: 'ff-1',  amount: 5,    bonus: 1,  price: 1500  },
      { id: 'ff-2',  amount: 12,   bonus: 2,  price: 4000  },
      { id: 'ff-3',  amount: 50,   bonus: 5,  price: 15000 },
      { id: 'ff-4',  amount: 100,  bonus: 10, price: 30000 },
      { id: 'ff-5',  amount: 210,  bonus: 20, price: 60000 },
      { id: 'ff-6',  amount: 520,  bonus: 50, price: 150000 },
      { id: 'ff-7',  amount: 1060, bonus: 106, price: 300000 },
    ],
  },
  {
    id: 'pubg',
    name: 'PUBG Mobile',
    image: 'https://i.imgur.com/nKgMLZq.png',
    category: 'Battle Royale',
    currency: 'UC',
    packages: [
      { id: 'pubg-1', amount: 60,   bonus: 0,  price: 14000  },
      { id: 'pubg-2', amount: 180,  bonus: 10, price: 40000  },
      { id: 'pubg-3', amount: 325,  bonus: 25, price: 74000  },
      { id: 'pubg-4', amount: 660,  bonus: 60, price: 144000 },
      { id: 'pubg-5', amount: 1800, bonus: 180, price: 399000 },
    ],
  },
  {
    id: 'genshin',
    name: 'Genshin Impact',
    image: 'https://i.imgur.com/RL0Ue4H.png',
    category: 'RPG',
    currency: 'Genesis Crystal',
    packages: [
      { id: 'genshin-1', amount: 60,   bonus: 0,  price: 14000  },
      { id: 'genshin-2', amount: 300,  bonus: 30, price: 69000  },
      { id: 'genshin-3', amount: 980,  bonus: 110, price: 229000 },
      { id: 'genshin-4', amount: 1980, bonus: 260, price: 449000 },
      { id: 'genshin-5', amount: 3280, bonus: 600, price: 749000 },
      { id: 'genshin-6', amount: 6480, bonus: 1600, price: 1499000 },
    ],
  },
];

// ─────────────────────────────────────────────
//  IN-MEMORY DATABASE (ganti dengan MySQL/MongoDB)
// ─────────────────────────────────────────────
const orders = new Map();

// ─────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────
function generateOrderId() {
  return 'ORD-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5).toUpperCase();
}

function getMidtransBaseUrl() {
  return CONFIG.MIDTRANS_IS_PRODUCTION
    ? 'https://app.midtrans.com/snap/v1'
    : 'https://app.sandbox.midtrans.com/snap/v1';
}

function getMidtransAuthHeader() {
  const encoded = Buffer.from(CONFIG.MIDTRANS_SERVER_KEY + ':').toString('base64');
  return 'Basic ' + encoded;
}

// ─────────────────────────────────────────────
//  ROUTES — GAME & PAKET
// ─────────────────────────────────────────────
app.get('/api/games', (req, res) => {
  res.json({ success: true, data: GAMES });
});

app.get('/api/games/:gameId', (req, res) => {
  const game = GAMES.find(g => g.id === req.params.gameId);
  if (!game) return res.status(404).json({ success: false, message: 'Game tidak ditemukan' });
  res.json({ success: true, data: game });
});

// ─────────────────────────────────────────────
//  ROUTES — ORDER & PAYMENT
// ─────────────────────────────────────────────

// Buat order baru + request Snap Token ke Midtrans
app.post('/api/orders', async (req, res) => {
  try {
    const { gameId, packageId, userId, userServer, email, phone } = req.body;

    // Validasi input
    if (!gameId || !packageId || !userId || !email) {
      return res.status(400).json({ success: false, message: 'Data tidak lengkap' });
    }

    const game = GAMES.find(g => g.id === gameId);
    if (!game) return res.status(404).json({ success: false, message: 'Game tidak ditemukan' });

    const pkg = game.packages.find(p => p.id === packageId);
    if (!pkg) return res.status(404).json({ success: false, message: 'Paket tidak ditemukan' });

    const orderId = generateOrderId();

    // Payload ke Midtrans
    const snapPayload = {
      transaction_details: {
        order_id: orderId,
        gross_amount: pkg.price,
      },
      item_details: [
        {
          id: pkg.id,
          price: pkg.price,
          quantity: 1,
          name: `${game.name} ${pkg.amount}${pkg.bonus ? '+'+pkg.bonus : ''} ${game.currency}`,
        },
      ],
      customer_details: {
        email: email,
        phone: phone || '',
      },
      callbacks: {
        finish: `${CONFIG.APP_URL}/success?order_id=${orderId}`,
        error:  `${CONFIG.APP_URL}/failed?order_id=${orderId}`,
        pending: `${CONFIG.APP_URL}/pending?order_id=${orderId}`,
      },
    };

    // Request ke Midtrans (hanya jika SERVER_KEY sudah diisi)
    let snapToken = null;
    let paymentUrl = null;

    if (CONFIG.MIDTRANS_SERVER_KEY !== 'YOUR_MIDTRANS_SERVER_KEY') {
      const mtRes = await fetch(`${getMidtransBaseUrl()}/transactions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: getMidtransAuthHeader(),
        },
        body: JSON.stringify(snapPayload),
      });
      const mtData = await mtRes.json();
      snapToken = mtData.token;
      paymentUrl = mtData.redirect_url;
    } else {
      // Mode demo: buat token palsu
      snapToken = 'DEMO-TOKEN-' + orderId;
      paymentUrl = `${CONFIG.APP_URL}/demo-payment?order_id=${orderId}`;
    }

    // Simpan order
    const order = {
      orderId,
      gameId,
      packageId,
      gameName: game.name,
      packageInfo: `${pkg.amount}${pkg.bonus ? '+'+pkg.bonus : ''} ${game.currency}`,
      price: pkg.price,
      userId,
      userServer: userServer || '-',
      email,
      phone: phone || '-',
      snapToken,
      paymentUrl,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
    };
    orders.set(orderId, order);

    res.json({
      success: true,
      data: {
        orderId,
        snapToken,
        paymentUrl,
        amount: pkg.price,
      },
    });
  } catch (err) {
    console.error('Order error:', err);
    res.status(500).json({ success: false, message: 'Gagal membuat order: ' + err.message });
  }
});

// Cek status order
app.get('/api/orders/:orderId', (req, res) => {
  const order = orders.get(req.params.orderId);
  if (!order) return res.status(404).json({ success: false, message: 'Order tidak ditemukan' });
  res.json({ success: true, data: order });
});

// ─────────────────────────────────────────────
//  WEBHOOK MIDTRANS  →  POST /api/payment/notify
// ─────────────────────────────────────────────
app.post('/api/payment/notify', (req, res) => {
  try {
    const notif = req.body;
    const { order_id, status_code, gross_amount, signature_key, transaction_status, fraud_status } = notif;

    // Verifikasi signature
    const hash = crypto
      .createHash('sha512')
      .update(order_id + status_code + gross_amount + CONFIG.MIDTRANS_SERVER_KEY)
      .digest('hex');

    if (hash !== signature_key) {
      return res.status(403).json({ success: false, message: 'Signature tidak valid' });
    }

    const order = orders.get(order_id);
    if (!order) return res.status(404).json({ success: false, message: 'Order tidak ditemukan' });

    // Update status
    if (transaction_status === 'capture' || transaction_status === 'settlement') {
      if (fraud_status === 'accept' || transaction_status === 'settlement') {
        order.status = 'SUCCESS';
        console.log(`✅ Order ${order_id} SUCCESS — proses top-up ke game di sini`);
        // TODO: panggil API game provider untuk proses top-up
      }
    } else if (['cancel', 'deny', 'expire'].includes(transaction_status)) {
      order.status = 'FAILED';
    } else if (transaction_status === 'pending') {
      order.status = 'PENDING';
    }

    orders.set(order_id, order);
    res.json({ success: true });
  } catch (err) {
    console.error('Webhook error:', err);
    res.status(500).json({ success: false });
  }
});

// Demo: simulasi pembayaran berhasil (hanya untuk mode demo)
app.post('/api/demo/pay/:orderId', (req, res) => {
  const order = orders.get(req.params.orderId);
  if (!order) return res.status(404).json({ success: false });
  order.status = 'SUCCESS';
  orders.set(req.params.orderId, order);
  res.json({ success: true, data: order });
});

// Serve frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/public/index.html'));
});

// ─────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🎮 TopUp Game Server berjalan di http://localhost:${PORT}`);
  console.log(`📋 Mode: ${CONFIG.MIDTRANS_IS_PRODUCTION ? 'PRODUCTION' : 'SANDBOX/DEMO'}`);
  if (CONFIG.MIDTRANS_SERVER_KEY === 'YOUR_MIDTRANS_SERVER_KEY') {
    console.log('⚠️  Midtrans belum dikonfigurasi — berjalan dalam mode DEMO\n');
  }
});
